import { JsonPipe, NgIf } from '@angular/common';
import { Component } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';

export interface User {
  name: string;
  email: string;
}

@Component({
  selector: 'app-reactive-form',
  templateUrl: './reactive-form.component.html',
  styleUrls: ['./reactive-form.component.css'],
  imports: [ReactiveFormsModule, NgIf, JsonPipe],
})
export class ReactiveFormComponent {
  submitted: boolean = false;
  form: FormGroup<{
    name: FormControl<string>;
    email: FormControl<string>;
  }>;

  constructor(private fb: FormBuilder) {
    this.form = this.fb.group({
      name: this.fb.control<string>('', {
        nonNullable: true,
        validators: [
          Validators.required,
          Validators.pattern('^[a-zA-Z\\s]+$'),
        ]
      }),
      email: this.fb.control<string>('', {
        nonNullable: true,
        validators: [
          Validators.required,
          Validators.email,
        ]
      }),
    });
  }

  get nameCtrl() {
    return this.form.controls.name;
  }

  get emailCtrl() {
    return this.form.controls.email;
  }

  onSubmit(): void {
    this.submitted = true;
    if (this.form.valid) {
      const user: User = this.form.getRawValue();
      console.log('Form Submitted!', user);
      this.form.reset()
      this.submitted = false;
    } else {
      console.log('Form is invalid');
    }
  }
}



// import { JsonPipe, NgIf } from '@angular/common';
// import { Component } from '@angular/core';
// import { FormBuilder, FormControl, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';

// export interface User {
//   name: string | null
//   email: string | null
// }

// @Component({
//   selector: 'app-reactive-form',
//   templateUrl: './reactive-form.component.html',
//   styleUrls: ['./reactive-form.component.css'],
//   imports: [ReactiveFormsModule, NgIf, JsonPipe],
// })
// export class ReactiveFormComponent {
//   submitted: boolean = false;
//   form: FormGroup<{
//     name: FormControl<string | null>;
//     email: FormControl<string | null>;
//   }>;

//   constructor(private fb: FormBuilder) {

//     this.form = this.fb.group({
//       name: this.fb.control<string | null>('', [
//         Validators.required,
//         Validators.pattern('^[a-zA-Z\\s]+$'),
//       ]),
//       email: this.fb.control<string | null>('', [
//         Validators.required,
//         Validators.email,
//       ]),
//     });
//   }

//   get nameCtrl() {
//     return this.form.controls.name;
//   }

//   get emailCtrl() {
//     return this.form.controls.email;
//   }

//   onSubmit(): void {
//     this.submitted = true
//     if (this.form.valid) {
//       const user: User = this.form.getRawValue()
//       console.log('Form Submitted!', this.form.value);
//     } else {
//       console.log('Form is invalid');
//     }
//   }
// }




// import { JsonPipe, NgIf } from '@angular/common';
// import { Component } from '@angular/core';
// import { FormControl, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';

// export interface User {
//   name: string;
//   email: string;
// }

// export interface UserForm {
//   name: FormControl<string>;
//   email: FormControl<string>;
// }

// @Component({
//   selector: 'app-reactive-form',
//   templateUrl: './reactive-form.component.html',
//   styleUrls: ['./reactive-form.component.css'],
//   imports: [ReactiveFormsModule, NgIf, JsonPipe],
// })
// export class ReactiveFormComponent {
//   submitted: boolean = false;

//   form: FormGroup<UserForm> = new FormGroup({
//     name: new FormControl<string>('', {
//       nonNullable: true,
//       validators: [
//         Validators.required,
//         Validators.pattern('^[a-zA-Z\\s]+$'),
//       ]
//     }),
//     email: new FormControl<string>('', {
//       nonNullable: true,
//       validators: [
//         Validators.required,
//         Validators.email,
//       ]
//     }),
//   });

//   get nameCtrl() {
//     return this.form.controls.name;
//   }

//   get emailCtrl() {
//     return this.form.controls.email;
//   }

//   onSubmit(): void {
//     this.submitted = true;
//     if (this.form.valid) {
//       const user: User = this.form.getRawValue();
//       console.log('Form Submitted!', this.form.value);
//     } else {
//       console.log('Form is invalid');
//     }
//   }
// }
