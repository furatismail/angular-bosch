import { JsonPipe, NgIf } from '@angular/common';
import { Component, ViewChild } from '@angular/core';
import { FormsModule, NgForm } from '@angular/forms';

export interface User {
  name: string
  email: string
}

@Component({
  selector: 'app-template-driven-form',
  imports: [FormsModule, NgIf, JsonPipe],
  templateUrl: './template-driven-form.component.html',
  styleUrl: './template-driven-form.component.css'
})
export class TemplateDrivenFormComponent {
  @ViewChild('formRef') formRef!: NgForm
  user: User = {
    name: '',
    email: '',
  };

  onSubmit(form: NgForm): void {
    const {valid, value} = form;
    if (valid) {
      console.log(value)
      console.log('Form Submitted!', this.user);
      this.formRef.reset()
      this.formRef.resetForm()
    }
  }
}
